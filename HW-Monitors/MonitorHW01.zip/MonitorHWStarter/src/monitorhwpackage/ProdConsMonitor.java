package monitorhwpackage;



public class ProdConsMonitor {
   
    private final int size;
    private final int buffer[];
    private int count = 0, lo = 0, hi = 0;
    public int inBlockCount = 0;
    public int outBlockCount = 0;
    
    public ProdConsMonitor(){
        super();
        this.size = HWMain.BUFFER_SIZE;
        this.buffer = new int [size];
    }
    
    public synchronized void insert(int value) {
        if (count == size) { 
            inBlockCount ++;
            goToSleep();
        }
        
        buffer[hi] = value;
        hi = (hi + 1) % size;
        count = count + 1; 
        
        if (count == 1) { 
            notify(); 
        }
    }

    public synchronized int remove() {
        int value;
        if (count == 0) { 
            outBlockCount++;
            goToSleep(); 
        }
        
        value = buffer[lo];
        lo = (lo + 1) % size;
        count = count - 1;
        
        if (count == size - 1) { 
            notify();    
        }
        return value;
    }
    
    // Jacketing for thread wait. DO NOT MODIFY
    private synchronized void goToSleep() {
        try {
            wait();
        } catch (InterruptedException e) {
           
        }
    }
    
    public int getInsertBlockedCount(){
        return this.inBlockCount;
    }
    
    public int getRemoveBlockedCount(){
        return this.outBlockCount;
    }
}
