package monitorhwpackage;

public class Producer extends Thread {
    
    public Producer(){
        super();
        
    }
    
    @Override
    public void run() {
        int randNum; 
        for (int i = 0; i < HWMain.NUM_ITEMS; i++) {
            randNum = (int )(Math.random() * 11);
            HWMain.pcm.insert(randNum);
        }
    }
}
