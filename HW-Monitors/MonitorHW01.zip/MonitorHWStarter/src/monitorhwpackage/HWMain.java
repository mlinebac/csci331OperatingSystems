/*Author Matt Lineback
 *Modified starter code from MonitorHWStarter package 
 *CSCI 331 HW01
 *
 */
package monitorhwpackage;

public class HWMain {

    public static final int BUFFER_SIZE = 100; 
    public static final int NUM_ITEMS = 10000000;
    public static Producer p = new Producer();
    public static Consumer c = new Consumer();
    public static ProdConsMonitor pcm = new ProdConsMonitor();
    
    public static void main(String[] args) throws InterruptedException {
        p.start();
        c.start();
        p.join();
        c.join();
        System.out.println("The monitor insert; blocked this many times: "
                + pcm.getInsertBlockedCount());
        System.out.println("The monitor remove; blocked this many times: "
                + pcm.getRemoveBlockedCount());

    }

}
