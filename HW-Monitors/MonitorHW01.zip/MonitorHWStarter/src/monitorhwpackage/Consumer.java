package monitorhwpackage;

public class Consumer extends Thread {
    
    public Consumer(){
        super();
    }
    
    @Override
    public void run() {
        int sum = 0;
        int randNum;
        for (int i = 0; i < HWMain.NUM_ITEMS; i++) {
           randNum = HWMain.pcm.remove();
           sum += randNum;
        }
       
        System.out.println("Summation of all consumed items " + sum );
    }
}
