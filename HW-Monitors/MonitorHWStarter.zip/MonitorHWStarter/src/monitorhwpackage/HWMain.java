/*
 * Header comment here
 */
package monitorhwpackage;

public class HWMain {

    public static final int BUFFER_SIZE = 100; // buffer size
    public static final int NUM_ITEMS = 1000000;
    // The ProdConsMonitor class's object can be a static field in this main class

    public static void main(String[] args) throws InterruptedException {
        // create producer and consumer objects.
        // start their threads, join their threads, and then finally
        // print out how many times the monitor insert blocked
        // and how many times the monitor remove blocked.

    }

}
